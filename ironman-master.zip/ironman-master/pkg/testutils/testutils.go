package testutils

import (
	"encoding/json"
	"testing"
)

//Marshal marshals the value to a string representation
func Marshal(val interface{}, t *testing.T) string {
	bytes, err := json.MarshalIndent(val, "", "    ")

	if err != nil {
		t.Fatalf("failed to marshal object %v", val)
	}
	return string(bytes)
}
