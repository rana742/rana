//This a generated file from template test and generator app
console.log("Foo is bar bar is foo")