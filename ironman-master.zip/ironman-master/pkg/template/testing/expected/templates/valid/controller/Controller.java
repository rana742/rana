/**
 * controller
 */
public class  FooController {
}