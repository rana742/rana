/**
 * controller
 */
public class  {{.Values.Name}}Controller {
}