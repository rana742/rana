//This a generated file from template {{.Template.Name}} and generator {{.Generator.Name}}
console.log("Foo is {{.Values.foo}} bar is {{.Values.bar}}")