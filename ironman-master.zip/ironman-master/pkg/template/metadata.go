package template

//Metadata template metadata
type Metadata struct {
	ID string
}
