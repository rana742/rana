package main

import "github.com/ironman-project/ironman/cmd"

func main() {
	cmd.Execute()
}
